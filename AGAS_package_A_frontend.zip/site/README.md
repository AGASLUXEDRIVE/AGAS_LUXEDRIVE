GitHub Pages ready build.
